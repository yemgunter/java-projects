public class Cat implements Animal {
    public String speak() {
        return "I am a cat.\nMy name is Cleo.";
    }// end speak method

    public void sleep(String data) {
        System.out.print(data + ":Snore - ");
    }// end sleep method

    public int run() {
        return 0;
    }// end run method
}

class Proj07Runner extends Proj07 {

    public Proj07Runner() {

	System.out.println(
        	"I certify that this program is my own work \n" +
                "and is not the work of others. I agree not \n" +
                "to share my solution with others.");
    }//end constructor

    public void run() {
        System.out.println(
		"Yolanda Gunter \n");
    }// end run
}// end class Proj07Runner


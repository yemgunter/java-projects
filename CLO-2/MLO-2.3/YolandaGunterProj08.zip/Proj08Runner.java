public class Proj08Runner {

    String run(String arg) {// first run method

        System.out.println(
                "=======This line is required in the output.======= \n" +
                        "=======This line is required in the output.======= \n" +
                        "=======This line is required in the output.=======");
        return "I certify that this program is my own work\n"
                + "and is not the work of others. I agree not\n"
                + "to share my solution with others.";
    }// end first run method

    String run(int num, String name) {// second run method
        return name = "Yolanda Gunter \n";
    }// end second run method

    byte run(int num) {// third run method converts the integer
        return (byte) num;
    }// end third run method
}
public class Proj12Runner {
    public Proj12Runner() {
        System.out.println(
                "I certify that this program is my own work\n" +
                        "and is not the work of others. I agree not\n" +
                        "to share my solution with others.\n" +
                        "Yolanda Gunter\n");
    }// end Certification

}// end class

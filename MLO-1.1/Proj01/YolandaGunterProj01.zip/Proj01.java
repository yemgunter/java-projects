class Proj01 {
    public static void main(String[] args) {
        System.out.println("I certify that this program is my own work");
        System.out.println("and is not the work of others. I agree not");
        System.out.println("to share my solution with others.");
        System.out.println("Yolanda Gunter");
        System.out.println("Hello World");
    }// end method
}// end class
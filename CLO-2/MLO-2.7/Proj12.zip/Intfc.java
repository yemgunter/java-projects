interface Animal{
  public String speak();
  public void sleep(String data);
  public int run();
}//end interface